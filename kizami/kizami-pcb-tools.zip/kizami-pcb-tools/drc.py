import sexpdata as S, math, sys
Sym=S.Symbol
pcb=S.loads(open(sys.argv[1]).read())
CLR=0.2
def rot(px,py,t):
    t=math.radians(t); return px*math.cos(t)+py*math.sin(t), -px*math.sin(t)+py*math.cos(t)
items=[]  # (layer, net, kind, geom) kind: 'seg'(x1,y1,x2,y2,w) 'rect'(x,y,w,h) 'circ'(x,y,r)
for e in pcb:
    if not isinstance(e,list): continue
    g=lambda k:[k2 for k2 in e if isinstance(k2,list) and k2[0]==Sym(k)]
    if e[0]==Sym('footprint'):
        at=g('at')[0]; X,Y=at[1],at[2]; R=at[3] if len(at)>3 else 0
        ref=[p for p in g('property') if p[1]=='Reference'][0][2]
        for p in g('pad'):
            pat=[k for k in p if isinstance(k,list) and k[0]==Sym('at')][0]; sz=[k for k in p if isinstance(k,list) and k[0]==Sym('size')][0]
            px,py=rot(pat[1],pat[2],R); pr=(pat[3] if len(pat)>3 else 0)%180
            w,h=(sz[1],sz[2]) if pr in (0,180) else (sz[2],sz[1])
            net=[k for k in p if isinstance(k,list) and k[0]==Sym('net')]; net=net[0][2] if net else f'NC:{ref}.{p[1]}'
            layers=['F.Cu','B.Cu'] if p[2] in (Sym('thru_hole'),Sym('np_thru_hole')) else ['F.Cu']
            for l in layers: items.append((l,net,'rect',(X+px,Y+py,w,h),f'{ref}.{p[1]}'))
    elif e[0]==Sym('segment'):
        a,b=g('start')[0],g('end')[0]; items.append((g('layer')[0][1],g('net')[0][1],'seg',(a[1],a[2],b[1],b[2],g('width')[0][1]),'seg'))
    elif e[0]==Sym('via'):
        a=g('at')[0]; r=g('size')[0][1]/2
        for l in ('F.Cu','B.Cu'): items.append((l,g('net')[0][1],'circ',(a[1],a[2],r),'via'))
netname={}
for e in pcb:
    if isinstance(e,list) and e[0]==Sym('net'): netname[e[1]]=e[2]
def nn(n): return netname.get(n,n) if isinstance(n,int) else n
def seg_pt(px,py,x1,y1,x2,y2):
    dx,dy=x2-x1,y2-y1; L2=dx*dx+dy*dy
    t=0 if L2==0 else max(0,min(1,((px-x1)*dx+(py-y1)*dy)/L2))
    return math.hypot(px-(x1+t*dx),py-(y1+t*dy))
def seg_seg(a,b):
    x1,y1,x2,y2=a[:4]; x3,y3,x4,y4=b[:4]
    # intersection test
    def ccw(ax,ay,bx,by,cx,cy): return (cy-ay)*(bx-ax)>(by-ay)*(cx-ax)
    if ccw(x1,y1,x3,y3,x4,y4)!=ccw(x2,y2,x3,y3,x4,y4) and ccw(x1,y1,x2,y2,x3,y3)!=ccw(x1,y1,x2,y2,x4,y4): return 0
    return min(seg_pt(x1,y1,*b[:4]),seg_pt(x2,y2,*b[:4]),seg_pt(x3,y3,*a[:4]),seg_pt(x4,y4,*a[:4]))
def rect_pt(px,py,x,y,w,h):
    dx=max(abs(px-x)-w/2,0); dy=max(abs(py-y)-h/2,0); return math.hypot(dx,dy)
def rect_seg(r,s):
    x,y,w,h=r; x1,y1,x2,y2=s[:4]
    # sample along segment
    n=max(2,int(math.hypot(x2-x1,y2-y1)/0.05)+1)
    return min(rect_pt(x1+(x2-x1)*i/(n-1),y1+(y2-y1)*i/(n-1),x,y,w,h) for i in range(n))
def dist(a,b):
    ka,ga=a[2],a[3]; kb,gb=b[2],b[3]
    if ka=='seg' and kb=='seg': return seg_seg(ga,gb)-ga[4]/2-gb[4]/2
    if ka=='seg' and kb=='rect': return rect_seg(gb,ga)-ga[4]/2
    if ka=='rect' and kb=='seg': return rect_seg(ga,gb)-gb[4]/2
    if ka=='circ' and kb=='seg': return seg_pt(ga[0],ga[1],*gb[:4])-ga[2]-gb[4]/2
    if ka=='seg' and kb=='circ': return dist(b,a)
    if ka=='circ' and kb=='rect': return rect_pt(ga[0],ga[1],*gb)-ga[2]
    if ka=='rect' and kb=='circ': return dist(b,a)
    if ka=='circ' and kb=='circ': return math.hypot(ga[0]-gb[0],ga[1]-gb[1])-ga[2]-gb[2]
    if ka=='rect' and kb=='rect':
        return max(abs(ga[0]-gb[0])-ga[2]/2-gb[2]/2, abs(ga[1]-gb[1])-ga[3]/2-gb[3]/2)  # approx (0 if overlapping)
def bbox(it):
    k,g=it[2],it[3]
    if k=='seg': return (min(g[0],g[2])-g[4],min(g[1],g[3])-g[4],max(g[0],g[2])+g[4],max(g[1],g[3])+g[4])
    if k=='rect': return (g[0]-g[2],g[1]-g[3],g[0]+g[2],g[1]+g[3])
    return (g[0]-g[2]-0.3,g[1]-g[2]-0.3,g[0]+g[2]+0.3,g[1]+g[2]+0.3)
viol=[]
by_layer={}
for it in items: by_layer.setdefault(it[0],[]).append((it,bbox(it)))
for l,lst in by_layer.items():
    for i,(a,ba) in enumerate(lst):
        for b,bb in lst[i+1:]:
            if nn(a[1])==nn(b[1]): continue
            if a[2]=='rect' and b[2]=='rect': continue  # pads vs pads: library's job
            if ba[0]>bb[2]+CLR or bb[0]>ba[2]+CLR or ba[1]>bb[3]+CLR or bb[1]>ba[3]+CLR: continue
            d=dist(a,b)
            if d<CLR-1e-6: viol.append((round(d,3),l,nn(a[1]),a[4],nn(b[1]),b[4],a[3] if a[2]!='rect' else None))
viol.sort()
print('violations',len(viol))
for v in viol[:25]: print(v)
