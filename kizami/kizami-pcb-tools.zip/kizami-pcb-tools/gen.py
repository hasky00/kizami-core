import re, uuid, sexpdata as S

LIB = {  # local file -> (library nickname, symbol name)
 'ESP32-WROOM-32':('RF_Module','ESP32-WROOM-32'), 'DS3231M':('Timer_RTC','DS3231M'),
 'CH340C':('Interface_USB','CH340C'), 'USB_C_Receptacle_USB2.0_16P':('Connector','USB_C_Receptacle_USB2.0_16P'),
 'AP1117-15':('Regulator_Linear','AP1117-15'), 'Q_NPN_EBC':('Transistor_BJT','Q_NPN_EBC'),
 'Conn_01x04':('Connector_Generic','Conn_01x04'), 'Conn_01x02':('Connector_Generic','Conn_01x02'),
 'Conn_01x03':('Connector_Generic','Conn_01x03'), 'R':('Device','R'), 'C':('Device','C'),
 'Battery_Cell':('Device','Battery_Cell'), '+3V3':('power','+3V3'), 'PWR_FLAG':('power','PWR_FLAG'), '+5V':('power','+5V'), 'GND':('power','GND'), 'MountingHole':('Mechanical','MountingHole'),
}
STRIP = ['in_pos_files','duplicate_pin_numbers_are_jumpers','show_name','do_not_autoplace']

def load_sym(fn):
    lib,name = LIB[fn]
    sym = S.loads(open(f'v9/{lib}__{name}.sexp').read())
    sym[1] = f"{lib}:{name}"
    # rename nested unit symbols? they keep bare names (e.g. R_0_1) - KiCad convention
    return sym

def pins_of(sym):
    out = {}
    def walk(x):
        if isinstance(x,list) and x and x[0]==S.Symbol('pin'):
            g=lambda k:[e for e in x if isinstance(e,list) and e[0]==S.Symbol(k)][0]
            out[g('number')[1]] = (g('at')[1], g('at')[2], g('at')[3])
        elif isinstance(x,list):
            for e in x: walk(e)
    walk(sym); return out

syms = {k: load_sym(k) for k in LIB}
def retype(sym, pinnum, newtype):
    def walk(x):
        if isinstance(x,list) and x and x[0]==S.Symbol('pin'):
            if [k for k in x if isinstance(k,list) and k[0]==S.Symbol('number')][0][1]==pinnum: x[1]=S.Symbol(newtype)
        elif isinstance(x,list):
            for e in x: walk(e)
    walk(sym)
retype(syms['CH340C'],'4','passive')
pins = {k: pins_of(v) for k,v in syms.items()}
U = lambda: str(uuid.uuid4())
PWRN=[0]
def pwrref():
    PWRN[0]+=1; return f'#PWR{PWRN[0]:02d}'
ROOT = U()
out = []      # schematic items (text)
def q(s): return '"' + s.replace('"','\\"') + '"'

def snap(v): return round(round(v/1.27)*1.27, 2)
def place(fn, ref, x, y, value, footprint='', props=None, hide_val=False, in_bom=True):
    x, y = snap(x), snap(y)
    lib = f"{LIB[fn][0]}:{LIB[fn][1]}"
    p = pins[fn]
    ys = [y - py for (px,py,a) in p.values()] ; xs=[x+px for (px,py,a) in p.values()]
    top = (min(ys) if ys else y) - 2.54; 
    ptxt = [
     f'(property "Reference" {q(ref)} (at {x:.2f} {top-2.54:.2f} 0) (effects (font (size 1.27 1.27))))',
     f'(property "Value" {q(value)} (at {x:.2f} {top:.2f} 0) (effects (font (size 1.27 1.27)){" hide" if hide_val else ""}))',
     f'(property "Footprint" {q(footprint)} (at {x:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes)))',
     f'(property "Datasheet" "~" (at {x:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes)))',
     f'(property "Description" "" (at {x:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes)))',
    ]
    for k,v in (props or {}).items():
        ptxt.append(f'(property {q(k)} {q(v)} (at {x:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes)))')
    pt = ''.join(f'(pin {q(n)} (uuid "{U()}"))' for n in p)
    out.append(f'(symbol (lib_id {q(lib)}) (at {x:.2f} {y:.2f} 0) (unit 1) (exclude_from_sim no) (in_bom {"yes" if in_bom else "no"}) (on_board yes) (dnp no) (uuid "{U()}") '
               + ' '.join(ptxt) + pt + f' (instances (project "kizami" (path "/{ROOT}" (reference {q(ref)}) (unit 1)))))')
    return (fn, x, y)

def pin_xy(inst, n):
    fn,x,y = inst; px,py,a = pins[fn][n]
    return x+px, y-py, a

def wire(x1,y1,x2,y2):
    out.append(f'(wire (pts (xy {x1:.2f} {y1:.2f}) (xy {x2:.2f} {y2:.2f})) (stroke (width 0) (type default)) (uuid "{U()}"))')

def net(inst, n, name, L=5.08):
    """label a pin: stub outward + local label"""
    x,y,a = pin_xy(inst,n)
    if a==0:   x2,y2,rot = x-L,y,180
    elif a==180: x2,y2,rot = x+L,y,0
    elif a==90:  x2,y2,rot = x,y+L,270
    else:        x2,y2,rot = x,y-L,90
    wire(x,y,x2,y2)
    just = {0:'left bottom',180:'right bottom',90:'left bottom',270:'right bottom'}[rot]
    out.append(f'(label {q(name)} (at {x2:.2f} {y2:.2f} {rot}) (effects (font (size 1.27 1.27)) (justify {just})) (uuid "{U()}"))')

def power(inst, n, kind, L=5.08):
    """connect pin to +3V3 / +5V / GND power symbol. Vertical pins: straight stub. Horizontal pins: stub + sideways symbol."""
    x,y,a = pin_xy(inst,n)
    up = kind != 'GND'
    rot = 0
    if a in (90,270):
        x2 = x; y2 = y - L if a==270 else y + L
        if (a==270) != up:      # wrong direction, add elbow
            wire(x,y,x2,y2); x3=x2+5.08; wire(x2,y2,x3,y2); y4 = y2-2.54 if up else y2+2.54; wire(x3,y2,x3,y4); x2,y2=x3,y4
        else:
            wire(x,y,x2,y2)
        vx,vy = x2, (y2-2.54 if up else y2+3.81)
    else:
        x2 = x-L if a==0 else x+L; y2 = y; wire(x,y,x2,y2)
        left = (a==0)
        # +V: rot 90 -> graphic left, 270 -> right.  GND: rot 270 -> left, 90 -> right
        rot = (90 if left else 270) if up else (270 if left else 90)
        vx,vy = (x2-7.62 if left else x2+7.62), y+0.5
    ref = pwrref()
    out.append(f'(symbol (lib_id "power:{kind}") (at {x2:.2f} {y2:.2f} {rot}) (unit 1) (exclude_from_sim no) (in_bom yes) (on_board yes) (dnp no) (uuid "{U()}") '
               f'(property "Reference" "{ref}" (at {x2:.2f} {y2:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
               f'(property "Value" {q(kind)} (at {vx:.2f} {vy:.2f} 0) (effects (font (size 1.27 1.27)))) '
               f'(property "Footprint" "" (at {x2:.2f} {y2:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
               f'(property "Datasheet" "" (at {x2:.2f} {y2:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
               f'(property "Description" "" (at {x2:.2f} {y2:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
               f'(pin "1" (uuid "{U()}")) (instances (project "kizami" (path "/{ROOT}" (reference "{ref}") (unit 1)))))')

def nc(inst, n):
    x,y,a = pin_xy(inst,n); out.append(f'(no_connect (at {x:.2f} {y:.2f}) (uuid "{U()}"))')

def text(s, x, y, size=2.54):
    out.append(f'(text {q(s)} (exclude_from_sim no) (at {x:.2f} {y:.2f} 0) (effects (font (size {size} {size}) bold) (justify left bottom)) (uuid "{U()}"))')

R_FP='Resistor_SMD:R_0603_1608Metric'; C_FP='Capacitor_SMD:C_0603_1608Metric'
HDR=lambda n:f'Connector_PinHeader_2.54mm:PinHeader_1x{n:02d}_P2.54mm_Vertical'
def res(ref,x,y,val,lcsc,a,b):
    r=place('R',ref,x,y,val,R_FP,{'LCSC':lcsc})
    for pin,n in (('1',a),('2',b)):
        if n in ('+3V3','+5V','GND'): power(r,pin,n,2.54)
        else: net(r,pin,n,2.54)
def cap(ref,x,y,val,lcsc,a,b):
    c=place('C',ref,x,y,val,C_FP,{'LCSC':lcsc})
    for pin,n in (('1',a),('2',b)):
        if n in ('+3V3','+5V','GND'): power(c,pin,n,2.54)
        else: net(c,pin,n,2.54)

# ---------------- MCU ----------------
text("KIZAMI CORE  ·  rev A  ·  ESP32 + DS3231 timecode  ·  Hasky Labs", 20, 20, 3.5)
text("MCU", 60, 60)
u1 = place('ESP32-WROOM-32','U1',100,120,'ESP32-WROOM-32','RF_Module:ESP32-WROOM-32',{'LCSC':'C82899'})
power(u1,'2','+3V3'); power(u1,'1','GND')
net(u1,'3','EN'); net(u1,'25','IO0'); net(u1,'35','U0TXD'); net(u1,'34','U0RXD')
net(u1,'33','SDA'); net(u1,'36','SCL'); net(u1,'26','BTN1'); net(u1,'12','BTN2'); net(u1,'10','DAC_LTC')
for n in ['4','5','6','7','8','9','11','13','14','16','17','18','19','20','21','22','23','24','27','28','29','30','31','32','37']: nc(u1,n)
# strapping / reset network
res('R3',150,90,'10k','C25804','+3V3','EN'); cap('C1',160,90,'1uF','C15849','EN','GND')
res('R4',170,90,'10k','C25804','+3V3','IO0')
cap('C2',150,110,'10uF','C19702','+3V3','GND'); cap('C3',160,110,'100nF','C14663','+3V3','GND')
text("EN pull-up + reset cap · IO0 pull-up · VDD decoupling", 145, 128, 1.5)

# ---------------- RTC ----------------
text("RTC · battery backed", 230, 60)
u2 = place('DS3231M','U2',250,90,'DS3231SN','Package_SO:SOIC-16W_7.5x10.3mm_P1.27mm')
power(u2,'2','+3V3'); power(u2,'5','GND'); net(u2,'14','VBAT'); net(u2,'15','SDA'); net(u2,'16','SCL')
nc(u2,'1'); nc(u2,'3'); nc(u2,'4')
bt=place('Battery_Cell','BT1',290,90,'CR2032','Battery:BatteryHolder_Keystone_3034_1x20mm')
net(bt,'1','VBAT',2.54); power(bt,'2','GND',2.54)
res('R1',230,120,'4.7k','C23162','+3V3','SDA'); res('R2',240,120,'4.7k','C23162','+3V3','SCL')
cap('C9',260,120,'100nF','C14663','+3V3','GND')
text("I2C pull-ups · RTC decoupling", 225, 130, 1.5)

# ---------------- OLED ----------------
text("OLED 0.96\" SSD1306 (module, 4-pin header)", 320, 60)
j1=place('Conn_01x04','J1',340,90,'OLED GND VCC SCL SDA',HDR(4))
power(j1,'1','GND'); power(j1,'2','+3V3'); net(j1,'3','SCL'); net(j1,'4','SDA')

# ---------------- Buttons ----------------
text("Panel buttons (wired to header)", 320, 120)
j2=place('Conn_01x02','J2',340,135,'BTN1 REC',HDR(2)); net(j2,'1','BTN1'); power(j2,'2','GND')
j3=place('Conn_01x02','J3',340,150,'BTN2 MENU',HDR(2)); net(j3,'1','BTN2'); power(j3,'2','GND')
res('R8',360,135,'10k','C25804','+3V3','BTN1'); res('R9',370,135,'10k','C25804','+3V3','BTN2')

# ---------------- LTC out ----------------
text("LTC / timecode out (DAC1 -> RC -> AC couple -> 3.5 mm jack)", 320, 175)
res('R10',330,195,'1k','C21190','DAC_LTC','LTC_A'); cap('C7',340,195,'10nF','C57112','LTC_A','GND')
cap('C8',350,195,'10uF','C19702','LTC_A','LTC_OUT')
j4=place('Conn_01x03','J4',380,195,'JACK TIP RING SLEEVE',HDR(3)); net(j4,'1','LTC_OUT'); nc(j4,'2'); power(j4,'3','GND')

# ---------------- USB-C + regulator ----------------
text("USB-C power + serial", 20, 190)
j6=place('USB_C_Receptacle_USB2.0_16P','J6',40,230,'USB-C','Connector_USB:USB_C_Receptacle_HRO_TYPE-C-31-M-12',{'LCSC':'C165948'})
power(j6,'A4','+5V'); power(j6,'A1','GND'); power(j6,'S1','GND')
net(j6,'A5','CC1'); net(j6,'B5','CC2'); net(j6,'A6','D+'); net(j6,'B6','D+'); net(j6,'A7','D-'); net(j6,'B7','D-'); nc(j6,'A8'); nc(j6,'B8')
res('R5',80,250,'5.1k','C23186','CC1','GND'); res('R6',90,250,'5.1k','C23186','CC2','GND')
text("5.1k CC pull-downs = 'I am a 5 V sink'", 75, 262, 1.5)

text("3.3 V regulator", 120, 190)
u4=place('AP1117-15','U4',140,210,'AMS1117-3.3','Package_TO_SOT_SMD:SOT-223-3_TabPin2',{'LCSC':'C6186'})
power(u4,'3','+5V'); power(u4,'2','+3V3'); power(u4,'1','GND')
cap('C4',120,235,'10uF','C19702','+5V','GND'); cap('C5',160,235,'10uF','C19702','+3V3','GND')

# ---------------- USB serial + auto reset ----------------
text("USB serial (CH340C) + auto-reset", 200, 190)
u3=place('CH340C','U3',220,225,'CH340C','Package_SO:SOIC-16_3.9x9.9mm_P1.27mm',{'LCSC':'C84681'})
power(u3,'16','+3V3'); power(u3,'4','+3V3'); power(u3,'1','GND')
net(u3,'5','D+'); net(u3,'6','D-'); net(u3,'2','U0RXD'); net(u3,'3','U0TXD'); net(u3,'13','DTR'); net(u3,'14','RTS')
for n in ['7','8','9','10','11','12','15']: nc(u3,n)
cap('C6',250,250,'100nF','C14663','+3V3','GND')
q1=place('Q_NPN_EBC','Q1',280,215,'S8050','Package_TO_SOT_SMD:SOT-23',{'LCSC':'C2146'})
net(q1,'1','DTR',2.54); net(q1,'3','EN',2.54); net(q1,'2','Q1B',2.54)
res('R7',265,205,'10k','C25804','RTS','Q1B')
q2=place('Q_NPN_EBC','Q2',280,245,'S8050','Package_TO_SOT_SMD:SOT-23',{'LCSC':'C2146'})
net(q2,'1','RTS',2.54); net(q2,'3','IO0',2.54); net(q2,'2','Q2B',2.54)
res('R11',265,235,'10k','C25804','DTR','Q2B')
text("Q1: DTR->E, RTS->B, EN->C   Q2: RTS->E, DTR->B, IO0->C  (standard ESP32 devkit reset)", 200, 270, 1.5)

# ---------------- power flags ----------------
text("Power flags (tell ERC where +5V, GND, VBAT come from)", 20, 285, 1.5)
def flag(kind, x, y):
    wire(x, y, x+5.08, y)
    if kind in ('+5V','GND','+3V3'):
        # fake instance to reuse power(): place power symbol directly
        ref=pwrref()
        out.append(f'(symbol (lib_id "power:{kind}") (at {x:.2f} {y:.2f} 0) (unit 1) (exclude_from_sim no) (in_bom yes) (on_board yes) (dnp no) (uuid "{U()}") '
          f'(property "Reference" "{ref}" (at {x:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
          f'(property "Value" "{kind}" (at {x:.2f} {y-2.54:.2f} 0) (effects (font (size 1.27 1.27)))) '
          f'(property "Footprint" "" (at {x:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
          f'(property "Datasheet" "" (at {x:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
          f'(property "Description" "" (at {x:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
          f'(pin "1" (uuid "{U()}")) (instances (project "kizami" (path "/{ROOT}" (reference "{ref}") (unit 1)))))')
    else:
        out.append(f'(label {q(kind)} (at {x:.2f} {y:.2f} 180) (effects (font (size 1.27 1.27)) (justify right bottom)) (uuid "{U()}"))')
    ref=f'#FLG{PWRN[0]+1:02d}'; PWRN[0]+=1; fx=x+5.08
    out.append(f'(symbol (lib_id "power:PWR_FLAG") (at {fx:.2f} {y:.2f} 0) (unit 1) (exclude_from_sim no) (in_bom yes) (on_board yes) (dnp no) (uuid "{U()}") '
      f'(property "Reference" "{ref}" (at {fx:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
      f'(property "Value" "PWR_FLAG" (at {fx:.2f} {y-3.81:.2f} 0) (effects (font (size 1.27 1.27)))) '
      f'(property "Footprint" "" (at {fx:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
      f'(property "Datasheet" "" (at {fx:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
      f'(property "Description" "" (at {fx:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) (hide yes))) '
      f'(pin "1" (uuid "{U()}")) (instances (project "kizami" (path "/{ROOT}" (reference "{ref}") (unit 1)))))')
flag('+5V', 30.48, 289.56); flag('GND', 50.8, 289.56); flag('VBAT', 71.12, 289.56)

# ---------------- mounting holes ----------------
text("Mounting holes M3 (enclosure screws)", 130, 265, 1.5)
for i in range(4):
    place('MountingHole',f'H{i+1}',130+i*12.7,275,'M3','MountingHole:MountingHole_3.2mm_M3',in_bom=False)

# ---------------- write file ----------------
lib_txt = '\n'.join(S.dumps(syms[k], true_as='yes', false_as='no') for k in syms)
sch = f'''(kicad_sch (version 20250114) (generator "eeschema") (generator_version "9.0")
 (uuid "{ROOT}")
 (paper "A3")
 (title_block (title "Kizami Core") (date "2026-09-20") (rev "A") (company "Hasky Labs"))
 (lib_symbols
{lib_txt}
 )
{chr(10).join(out)}
 (sheet_instances (path "/" (page "1")))
)
'''
open('/mnt/user-data/outputs/kizami.kicad_sch','w').write(sch)
S.loads(sch)  # syntax check
print("ok", len(sch))
