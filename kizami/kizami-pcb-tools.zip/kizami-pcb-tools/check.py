import sexpdata as S, sys
from collections import defaultdict
sch=S.loads(open(sys.argv[1]).read())
libs={}
for e in sch:
    if isinstance(e,list) and e[0]==S.Symbol('lib_symbols'):
        for s in e[1:]: libs[s[1]]=s
def pins_of(sym):
    out=[]
    def walk(x):
        if isinstance(x,list) and x and x[0]==S.Symbol('pin'):
            g=lambda k:[e for e in x if isinstance(e,list) and e[0]==S.Symbol(k)][0]
            out.append((g('number')[1], g('at')[1], g('at')[2]))
        elif isinstance(x,list):
            for e in x: walk(e)
    walk(sym); return out
key=lambda x,y:(round(x,2),round(y,2))
parent={}
def find(a):
    parent.setdefault(a,a)
    while parent[a]!=a: parent[a]=parent[parent[a]]; a=parent[a]
    return a
def union(a,b): parent[find(a)]=find(b)
segs=[]; pts=defaultdict(list); labels={}
for e in sch:
    if not isinstance(e,list): continue
    t=e[0].value() if isinstance(e[0],S.Symbol) else ''
    g=lambda k:[k2 for k2 in e if isinstance(k2,list) and k2[0]==S.Symbol(k)]
    if t=='wire':
        a,b=g('pts')[0][1],g('pts')[0][2]; segs.append((key(a[1],a[2]),key(b[1],b[2])))
    elif t=='label':
        at=g('at')[0]; pts[key(at[1],at[2])].append('LBL:'+e[1])
    elif t=='symbol':
        lid=g('lib_id')[0][1]; at=g('at')[0]; ref=[p for p in g('property') if p[1]=='Reference'][0][2]
        for num,px,py in pins_of(libs[lid]):
            k=key(at[1]+px, at[2]-py)
            pts[k].append(f'{ref}.{num}' if not lid.startswith('power:') else 'PWR:'+lid.split(':')[1]+'@'+ref)
def on_seg(p,s):
    (x1,y1),(x2,y2)=s; x,y=p
    return min(x1,x2)-1e-3<=x<=max(x1,x2)+1e-3 and min(y1,y2)-1e-3<=y<=max(y1,y2)+1e-3 and abs((x2-x1)*(y-y1)-(y2-y1)*(x-x1))<1e-3
allpts=set(pts)|{p for s in segs for p in s}
for s in segs:
    inside=[p for p in allpts if on_seg(p,s)]
    for p in inside: union(p,s[0])
byname=defaultdict(list)
for k,v in pts.items():
    for x in v:
        if x.startswith('LBL:'): byname[x[4:]].append(k)
        if x.startswith('PWR:') and 'PWR_FLAG' not in x: byname[x[4:].split('@')[0]].append(k)
for n,ks in byname.items():
    for k in ks[1:]: union(ks[0],k)
nets=defaultdict(set); members=defaultdict(list)
for k,v in pts.items():
    r=find(k)
    for x in v:
        if x.startswith('LBL:'): nets[r].add(x[4:])
        elif x.startswith('PWR:') and 'PWR_FLAG' not in x: nets[r].add(x[4:].split('@')[0])
        else: members[r].append(x)
bad=0
for r in set(nets)|set(members):
    ns=nets.get(r,set()); ms=[m for m in members.get(r,[]) if not m.startswith('PWR:')]
    if len(ns)>1: print('SHORT:',ns); bad+=1
    if len(ms)<2 and not ns: print('dangling:',ms); bad+=1
    if len(ms)+len(ns)<=1: print('single-pin net:',ns,ms); bad+=1
print('nets:',len(set(nets)|set(members)),'problems:',bad)
for r in sorted(set(nets)|set(members), key=lambda r:sorted(nets.get(r,{'~'}))[0]):
    print(sorted(nets.get(r,set())), sorted(m for m in members.get(r,[]) if not m.startswith('PWR:')))
