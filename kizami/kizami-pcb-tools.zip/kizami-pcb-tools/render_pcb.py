import sexpdata as S, math, sys, cairosvg
Sym=S.Symbol
pcb=S.loads(open(sys.argv[1]).read())
W,H=80,45; sc=12
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-6 -6 {W+12} {H+12}" width="{(W+12)*sc}" height="{(H+12)*sc}" font-family="monospace">',
     f'<rect x="-6" y="-6" width="{W+12}" height="{H+12}" fill="#eee"/><rect x="0" y="0" width="{W}" height="{H}" fill="#1b5e20" stroke="#ff0" stroke-width="0.2"/>']
def rot(px,py,t):
    t=math.radians(t); return px*math.cos(t)+py*math.sin(t), -px*math.sin(t)+py*math.cos(t)
courts=[]
for e in pcb:
    if not (isinstance(e,list) and e[0]==Sym('footprint')): continue
    g=lambda k:[k2 for k2 in e if isinstance(k2,list) and k2[0]==Sym(k)]
    at=g('at')[0]; X,Y=at[1],at[2]; R=at[3] if len(at)>3 else 0
    ref=[p for p in g('property') if p[1]=='Reference'][0][2]
    xs=[];ys=[]
    for l in g('fp_line'):
        layer=[k for k in l if isinstance(k,list) and k[0]==Sym('layer')][0][1]
        if layer not in ('F.CrtYd','F.Fab'): continue
        s=[k for k in l if isinstance(k,list) and k[0]==Sym('start')][0]; en=[k for k in l if isinstance(k,list) and k[0]==Sym('end')][0]
        x1,y1=rot(s[1],s[2],R); x2,y2=rot(en[1],en[2],R)
        col='#ffb' if layer=='F.Fab' else '#f8f'
        svg.append(f'<line x1="{X+x1:.2f}" y1="{Y+y1:.2f}" x2="{X+x2:.2f}" y2="{Y+y2:.2f}" stroke="{col}" stroke-width="{0.15 if layer=="F.Fab" else 0.1}"/>')
        if layer=='F.CrtYd' and ref!='U1': xs+=[X+x1,X+x2]; ys+=[Y+y1,Y+y2]
    for l in g('fp_circle'):
        layer=[k for k in l if isinstance(k,list) and k[0]==Sym('layer')][0][1]
        if layer!='F.CrtYd': continue
        c=[k for k in l if isinstance(k,list) and k[0]==Sym('center')][0]; en=[k for k in l if isinstance(k,list) and k[0]==Sym('end')][0]
        r=math.hypot(en[1]-c[1],en[2]-c[2]); svg.append(f'<circle cx="{X+c[1]}" cy="{Y+c[2]}" r="{r}" fill="none" stroke="#f8f" stroke-width="0.1"/>')
        xs+=[X+c[1]-r,X+c[1]+r]; ys+=[Y+c[2]-r,Y+c[2]+r]
    if xs: courts.append((ref,min(xs),min(ys),max(xs),max(ys)))
    for p in g('pad'):
        pat=[k for k in p if isinstance(k,list) and k[0]==Sym('at')][0]; sz=[k for k in p if isinstance(k,list) and k[0]==Sym('size')][0]
        px,py=rot(pat[1],pat[2],R); pr=(pat[3] if len(pat)>3 else 0)
        w,h=sz[1],sz[2]
        net=[k for k in p if isinstance(k,list) and k[0]==Sym('net')]
        col='#c8a000' if p[2]==Sym('smd') else '#bbb'
        if net and net[0][2]=='GND': col='#888'
        svg.append(f'<rect x="{-w/2}" y="{-h/2}" width="{w}" height="{h}" fill="{col}" transform="translate({X+px:.3f} {Y+py:.3f}) rotate({-pr})"/>')
        if net: svg.append(f'<text x="{X+px:.2f}" y="{Y+py+0.25:.2f}" font-size="0.5" fill="#000" text-anchor="middle">{net[0][2].replace("/","")}</text>')
    svg.append(f'<text x="{X:.2f}" y="{Y-0.5:.2f}" font-size="1.4" fill="#fff" text-anchor="middle" font-weight="bold">{ref}</text>')
for e in pcb:
    if isinstance(e,list) and e[0]==Sym('segment'):
        g=lambda k:[k2 for k2 in e if isinstance(k2,list) and k2[0]==Sym(k)][0]
        a,b,w,l=g('start'),g('end'),g('width')[1],g('layer')[1]
        col='#ff5252' if l=='F.Cu' else '#448aff'
        svg.append(f'<line x1="{a[1]}" y1="{a[2]}" x2="{b[1]}" y2="{b[2]}" stroke="{col}" stroke-width="{w}" stroke-linecap="round" opacity="0.9"/>')
    if isinstance(e,list) and e[0]==Sym('via'):
        g=lambda k:[k2 for k2 in e if isinstance(k2,list) and k2[0]==Sym(k)][0]
        a=g('at'); svg.append(f'<circle cx="{a[1]}" cy="{a[2]}" r="0.3" fill="#ddd" stroke="#000" stroke-width="0.05"/>')
svg.append('</svg>'); open('pcb_preview.svg','w').write('\n'.join(svg))
cairosvg.svg2png(url='pcb_preview.svg', write_to='pcb_preview.png', output_width=1800)
# courtyard overlap check
for i,a in enumerate(courts):
    for b in courts[i+1:]:
        if a[1]<b[3] and b[1]<a[3] and a[2]<b[4] and b[2]<a[4]: print('OVERLAP', a[0], b[0])
    if a[1]<0 or a[2]<0 or a[3]>W or a[4]>H: print('OFF-BOARD', a)
