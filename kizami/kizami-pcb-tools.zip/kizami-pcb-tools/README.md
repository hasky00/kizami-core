# Kizami Core — PCB generator tools

Scripts that generate the KiCad files for the Kizami Core board. No mouse work needed.

    pip install sexpdata numpy cairosvg
    python3 gen.py                       # -> kizami.kicad_sch  (edit the parts/nets at the bottom of gen.py)
    python3 check.py  kizami.kicad_sch   # my own ERC: nets, shorts, dangling pins
    python3 gen_pcb.py                   # -> kizami.kicad_pcb  (placement table PLACE = {...} in gen_pcb.py)
    python3 route.py  kizami.kicad_pcb kizami.kicad_pcb   # autoroute in place, GND via stitching, tidy
    python3 drc.py    kizami.kicad_pcb   # my own clearance check (0.2 mm)
    python3 render_pcb.py kizami.kicad_pcb   # -> pcb_preview.png

Outputs are written to /mnt/user-data/outputs/ by default — change SCH / output paths at the top of gen.py, gen_pcb.py.
v9/ = KiCad 9.0.5 symbols used (Mechanical, Device, RF_Module, ...). fp/ = KiCad 9.0.5 footprints.

Board: 80 x 45 mm, 2 layer, 4 x M3 holes 4 mm in from each corner, USB-C on the front edge, ESP32 antenna over the top edge.
Status 21 Sep 2026: KiCad DRC 0 errors, 0 unconnected. Next: File > Fabrication Outputs > Gerbers + Drill, upload to JLCPCB.
