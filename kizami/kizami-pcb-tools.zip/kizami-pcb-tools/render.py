import sexpdata as S, sys
sch=S.loads(open(sys.argv[1]).read())
libs={}
for e in sch:
    if isinstance(e,list) and e[0]==S.Symbol('lib_symbols'):
        for s in e[1:]: libs[s[1]]=s
def bbox(sym):
    xs=[];ys=[]
    def walk(x):
        if isinstance(x,list) and x:
            if x[0]==S.Symbol('rectangle'):
                st=[k for k in x if isinstance(k,list) and k[0]==S.Symbol('start')][0]; en=[k for k in x if isinstance(k,list) and k[0]==S.Symbol('end')][0]
                xs.extend([st[1],en[1]]); ys.extend([st[2],en[2]])
            if x[0]==S.Symbol('pin'):
                at=[k for k in x if isinstance(k,list) and k[0]==S.Symbol('at')][0]; xs.append(at[1]); ys.append(at[2])
            if x[0]==S.Symbol('xy'): xs.append(x[1]); ys.append(x[2])
            for k in x: walk(k)
    walk(sym); return (min(xs),min(ys),max(xs),max(ys)) if xs else (0,0,0,0)
svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 420 297" font-family="monospace"><rect width="420" height="297" fill="#fff"/>']
for e in sch:
    if not isinstance(e,list): continue
    t=e[0].value() if isinstance(e[0],S.Symbol) else ''
    g=lambda k:[k2 for k2 in e if isinstance(k2,list) and k2[0]==S.Symbol(k)]
    if t=='symbol':
        lid=g('lib_id')[0][1]; at=g('at')[0]; x,y=at[1],at[2]
        bx=bbox(libs[lid])
        svg.append(f'<rect x="{x+bx[0]}" y="{y-bx[3]}" width="{bx[2]-bx[0]}" height="{bx[3]-bx[1]}" fill="#fff8c0" stroke="#800" stroke-width="0.3"/>')
        ref=[p for p in g('property') if p[1]=='Reference'][0]; val=[p for p in g('property') if p[1]=='Value'][0]
        if not lid.startswith('power'):
            svg.append(f'<text x="{ref[3][1]}" y="{ref[3][2]}" font-size="2" fill="#008">{ref[2]}</text><text x="{val[3][1]}" y="{val[3][2]}" font-size="2" fill="#008">{val[2]}</text>')
        else:
            svg.append(f'<text x="{x-3}" y="{y-1 if lid!="power:GND" else y+3}" font-size="1.6" fill="#a00">{val[2]}</text>')
    elif t=='wire':
        a,b=g('pts')[0][1],g('pts')[0][2]
        svg.append(f'<line x1="{a[1]}" y1="{a[2]}" x2="{b[1]}" y2="{b[2]}" stroke="#080" stroke-width="0.3"/>')
    elif t=='label':
        at=g('at')[0]; rot=at[3]; anchor={0:'start',180:'end',90:'start',270:'end'}[rot]
        tr=f' transform="rotate(-90 {at[1]} {at[2]})"' if rot in (90,270) else ''
        svg.append(f'<text x="{at[1]}" y="{at[2]-0.3}" font-size="1.6" text-anchor="{anchor}" fill="#060"{tr}>{e[1]}</text>')
    elif t=='no_connect':
        at=g('at')[0]; svg.append(f'<text x="{at[1]}" y="{at[2]+0.6}" font-size="2" text-anchor="middle" fill="#00a">x</text>')
    elif t=='text':
        at=g('at')[0]; sz=[k for k in g('effects')[0][1] if isinstance(k,list) and k[0]==S.Symbol('size')][0][1]
        svg.append(f'<text x="{at[1]}" y="{at[2]}" font-size="{sz}" font-weight="bold">{e[1]}</text>')
svg.append('</svg>'); open('preview.svg','w').write('\n'.join(svg))
import cairosvg; cairosvg.svg2png(url='preview.svg', write_to='preview.png', output_width=2400)
