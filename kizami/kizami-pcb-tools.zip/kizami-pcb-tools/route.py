import sexpdata as S, math, heapq, uuid, sys
import numpy as np
Sym=S.Symbol
SRC=sys.argv[1]; DST=sys.argv[2]
txt=open(SRC).read(); pcb=S.loads(txt)
W,H=80.0,45.0; G=0.1; NX,NY=int(W/G)+1,int(H/G)+1
TRACK=0.2; POWER=0.4; CLR=0.2; VIA_D=0.6; VIA_DR=0.3
U=lambda:str(uuid.uuid4())
def rot(px,py,t):
    t=math.radians(t); return px*math.cos(t)+py*math.sin(t), -px*math.sin(t)+py*math.cos(t)
def cell(x,y): return int(round(x/G)), int(round(y/G))

# ---------- collect pads ----------
pads=[]  # dict(net, x,y,w,h,layers:set, ref, num)
keepout=[]  # rects (x1,y1,x2,y2)
for e in pcb:
    if not (isinstance(e,list) and e[0]==Sym('footprint')): continue
    g=lambda k:[k2 for k2 in e if isinstance(k2,list) and k2[0]==Sym(k)]
    at=g('at')[0]; X,Y=at[1],at[2]; R=at[3] if len(at)>3 else 0
    ref=[p for p in g('property') if p[1]=='Reference'][0][2]
    for p in g('pad'):
        pat=[k for k in p if isinstance(k,list) and k[0]==Sym('at')][0]; sz=[k for k in p if isinstance(k,list) and k[0]==Sym('size')][0]
        px,py=rot(pat[1],pat[2],R); pr=(pat[3] if len(pat)>3 else 0)%180
        w,h=(sz[1],sz[2]) if pr in (0,180) else (sz[2],sz[1])
        net=[k for k in p if isinstance(k,list) and k[0]==Sym('net')]
        typ=p[2].value()
        layers={'F.Cu','B.Cu'} if typ in ('thru_hole','np_thru_hole') else {'F.Cu'}
        pads.append(dict(net=net[0][2] if net else None, x=X+px, y=Y+py, w=w, h=h, layers=layers, ref=ref, num=p[1]))
    for z in g('zone'):
        if any(isinstance(k,list) and k[0]==Sym('keepout') for k in z):
            poly=[k for k in z if isinstance(k,list) and k[0]==Sym('polygon')][0][1]
            xs=[X+rot(pt[1],pt[2],R)[0] for pt in poly[1:]]; ys=[Y+rot(pt[1],pt[2],R)[1] for pt in poly[1:]]
            keepout.append((min(xs),min(ys),max(xs),max(ys)))
print('pads',len(pads),'keepout',keepout,file=sys.stderr)

# ---------- obstacle grids ----------
L={'F.Cu':0,'B.Cu':1}
block=np.zeros((2,NY,NX),dtype=bool)      # permanently blocked (other nets' copper + clearance)
owner=np.full((2,NY,NX),-1,dtype=np.int32) # net id occupying cell (pads/tracks) (-1 none)
trackowner=np.full((2,NY,NX),-1,dtype=np.int32)
nets=sorted({p['net'] for p in pads if p['net']})
nid={n:i for i,n in enumerate(nets)}
def fill_rect(arr,x1,y1,x2,y2,val,layers):
    cx1,cy1=cell(x1,y1); cx2,cy2=cell(x2,y2)
    cx1=max(cx1,0);cy1=max(cy1,0);cx2=min(cx2,NX-1);cy2=min(cy2,NY-1)
    for l in layers: arr[L[l],cy1:cy2+1,cx1:cx2+1]=val
# board edge
m=0.5
fill_rect(block,-1,-1,W+1,m,True,L); fill_rect(block,-1,H-m,W+1,H+1,True,L)
fill_rect(block,-1,-1,m,H+1,True,L); fill_rect(block,W-m,-1,W+1,H+1,True,L)
for k in keepout: fill_rect(block,k[0],k[1],k[2],k[3],True,L)
# pads: owner cells (copper), and clearance ring blocked for others (handled dynamically)
exp=CLR+TRACK/2
padcells={}
for i,p in enumerate(pads):
    if p['net'] is None:   # NPTH / unconnected -> block with generous clearance (hole clearance + widest track)
        e2=0.25+POWER/2+0.1
        fill_rect(block,p['x']-p['w']/2-e2,p['y']-p['h']/2-e2,p['x']+p['w']/2+e2,p['y']+p['h']/2+e2,True,p['layers'])
    else:
        fill_rect(owner,p['x']-p['w']/2,p['y']-p['h']/2,p['x']+p['w']/2,p['y']+p['h']/2,nid[p['net']],p['layers'])
# NC pads (net None but real pads) already blocked above.
# clearance halo of pads of *other* nets: computed per net at route time via dilation of owner!=me
def dilate(mask,r):
    out=mask.copy()
    for dy in range(-r,r+1):
        for dx in range(-r,r+1):
            if dx*dx+dy*dy>r*r+0.1: continue
            sh=np.roll(np.roll(mask,dy,axis=0),dx,axis=1)
            out|=sh
    return out
HALO=int(round(exp/G))
VIAR=int(round((VIA_D/2-TRACK/2)/G))+2

tracks=[]; vias=[]
# --- hand pre-route for the USB-C data/CC pads (fine pitch, interleaved D+/D-) ---
pre={}   # (ref,num) -> list of (layer,x,y) points that belong to that pad's net copper
def preline(net,x1,y1,x2,y2,layer='F.Cu',w=TRACK):
    tracks.append((x1,y1,x2,y2,w,layer,net))
    n=max(abs(x2-x1),abs(y2-y1))/G; pts=[]
    for i in range(int(n)+1):
        t=i/max(n,1); x=x1+(x2-x1)*t; y=y1+(y2-y1)*t; cx,cy=cell(x,y)
        owner[L[layer],cy,cx]=nid[net]; trackowner[L[layer],cy,cx]=nid[net]; pts.append((L[layer],cx,cy))
    return pts
def previa(net,x,y):
    vias.append((x,y,net)); cx,cy=cell(x,y); vr=int(round((VIA_D/2)/G))
    for dy in range(-vr,vr+1):
        for dx in range(-vr,vr+1):
            if dx*dx+dy*dy<=vr*vr: owner[:,cy+dy,cx+dx]=nid[net]; trackowner[:,cy+dy,cx+dx]=nid[net]
    return [(0,cx,cy),(1,cx,cy)]
P={(p['ref'],p['num']):p for p in pads}
def pad(ref,num): return P[(ref,num)]
a6,b6,a7,b7,a5,b5=[pad('J6',n) for n in ('A6','B6','A7','B7','A5','B5')]
top=a6['y']-a6['h']/2; bot=a6['y']+a6['h']/2
# D+ : A6 and B6 drop under the connector, join, via to bottom layer
pts=preline('/D+',a6['x'],a6['y'],a6['x'],bot+1.3)+preline('/D+',b6['x'],b6['y'],b6['x'],bot+1.3)+preline('/D+',a6['x'],bot+1.3,b6['x'],bot+1.3)+previa('/D+',(a6['x']+b6['x'])/2,bot+1.3)
pre[('J6','A6')]=pts; pre[('J6','B6')]=pts
# D- : B7 and A7 go up and join above the row (A6 has no up-stub now)
pts=preline('/D-',b7['x'],b7['y'],b7['x'],top-0.55)+preline('/D-',a7['x'],a7['y'],a7['x'],top-0.55)+preline('/D-',b7['x'],top-0.55,a7['x'],top-0.55)
pre[('J6','A7')]=pts; pre[('J6','B7')]=pts
# CC1 / CC2 : straight up stubs
pre[('J6','A5')]=preline('/CC1',a5['x'],a5['y'],a5['x'],top-1.2)
pre[('J6','B5')]=preline('/CC2',b5['x'],b5['y'],b5['x'],top-1.2)
# VBUS: A4/B9 (left) and A9/B4 (right) -> short vias above the row, joined on B.Cu
a4,a9=pad('J6','A4'),pad('J6','A9')
v1=(31.575,35.1); v2=(36.4,35.1)
pts=preline('+5V',a4['x'],a4['y'],v1[0],v1[1],'F.Cu',0.3)+previa('+5V',*v1)+preline('+5V',a9['x'],a9['y'],v2[0],v2[1],'F.Cu',0.3)+previa('+5V',*v2)+preline('+5V',v1[0],v1[1],v2[0],v2[1],'B.Cu',POWER)
for n in ('A4','B9','A9','B4'): pre[('J6',n)]=pts

def rect_mask(p,shrink=0.0):
    m=np.zeros((2,NY,NX),dtype=bool)
    hw=max(p['w']/2-shrink,0.0); hh=max(p['h']/2-shrink,0.0)
    fill_rect(m,p['x']-hw,p['y']-hh,p['x']+hw,p['y']+hh,True,p['layers']); return m

def route_net(n):
    me=nid[n]
    mypads=[p for p in pads if p['net']==n]
    if len(mypads)<2: return True
    w=POWER if n in ('+3V3','+5V','VBAT') else TRACK
    halo_exact=int(round((CLR+w/2)/G)); halo=halo_exact+1
    global VIAR; VIAR=int(round((VIA_D/2-w/2)/G))+1
    other=(owner!=-1)&(owner!=me)
    other_exact=np.zeros_like(other)
    for l in range(2): other_exact[l]=dilate(other[l],halo_exact)
    def rebuild():
        obs=block.copy()
        for l in range(2): obs[l]|=dilate(((owner!=-1)&(owner!=me))[l],halo)
        own=(trackowner==me)
        for p in mypads:
            m=rect_mask(p,w/2)
            for (l,cx,cy) in pre.get((p['ref'],p['num']),[]): m[l,cy,cx]=True
            own|=m
        own&=~other_exact
        obs[own]=False
        return obs
    obs=rebuild()
    def padmask(p):
        m=rect_mask(p,w/2)&~other_exact
        for (l,cx,cy) in pre.get((p['ref'],p['num']),[]): m[l,cy,cx]=True
        if not m.any():
            cx,cy=cell(p['x'],p['y'])
            for l in p['layers']: m[L[l],cy,cx]=True
        return m
    tree=np.zeros((2,NY,NX),dtype=bool)
    rem=mypads[:]; cur=rem.pop(0); tree|=padmask(cur)
    while rem:
        cx,cy=cur['x'],cur['y']
        rem.sort(key=lambda p:math.hypot(p['x']-cx,p['y']-cy)); tgt=rem.pop(0)
        tm=padmask(tgt)
        if (tree&tm).any(): tree|=tm; cur=tgt; continue
        path=astar(tree,tm,obs)
        if path is None:
            print('FAILED',n,tgt['ref'],tgt['num'],file=sys.stderr); return False
        emit(path,n)
        for endc in (path[0],path[-1]):
            l,cy_,cx_=endc; ex,ey=cx_*G,cy_*G
            for p in mypads:
                if ('F.Cu' if l==0 else 'B.Cu') in p['layers'] and abs(ex-p['x'])<=p['w']/2+0.06 and abs(ey-p['y'])<=p['h']/2+0.06:
                    if abs(ex-p['x'])>1e-6 or abs(ey-p['y'])>1e-6:
                        tracks.append((p['x'],p['y'],ex,ey,w,'F.Cu' if l==0 else 'B.Cu',n))
                    break
        extra=int(round(w/2/G))
        for (l,y,x) in path:
            tree[l,y,x]=True
            for dy in range(-extra,extra+1):
                for dx in range(-extra,extra+1):
                    if 0<=y+dy<NY and 0<=x+dx<NX: owner[l,y+dy,x+dx]=me; trackowner[l,y+dy,x+dx]=me
        for a,b in zip(path,path[1:]):
            if a[0]!=b[0]:
                vr=int(round((VIA_D/2)/G))
                for dy in range(-vr,vr+1):
                    for dx in range(-vr,vr+1):
                        if dx*dx+dy*dy<=vr*vr and 0<=a[1]+dy<NY and 0<=a[2]+dx<NX: owner[:,a[1]+dy,a[2]+dx]=me; trackowner[:,a[1]+dy,a[2]+dx]=me
        obs=rebuild()
        tree|=tm; cur=tgt
    return True

def astar(srcmask,tgtmask,obs):
    # multi-source multi-target A* on (layer,y,x)
    tgt_cells=np.argwhere(tgtmask)
    if len(tgt_cells)==0: return None
    ty,tx=tgt_cells[:,1].mean(),tgt_cells[:,2].mean()
    def h(l,y,x): return math.hypot(y-ty,x-tx)*0.99
    INF=1e18
    dist={}; prev={}; pq=[]
    for l,y,x in np.argwhere(srcmask):
        dist[(l,y,x)]=0; heapq.heappush(pq,(h(l,y,x),0,(l,y,x)))
    moves=[(0,1,1),(0,-1,1),(1,0,1),(-1,0,1),(1,1,1.42),(1,-1,1.42),(-1,1,1.42),(-1,-1,1.42)]
    seen=set(); n=0
    while pq:
        f,d,cur=heapq.heappop(pq)
        if cur in seen: continue
        seen.add(cur); n+=1
        l,y,x=cur
        if tgtmask[l,y,x]:
            path=[cur]
            while cur in prev: cur=prev[cur]; path.append(cur)
            return path[::-1]
        if n>2500000: return None
        for dy,dx,c in moves:
            ny,nx=y+dy,x+dx
            if not(0<=ny<NY and 0<=nx<NX): continue
            if obs[l,ny,nx]: continue
            if dy and dx and (obs[l,y,nx] or obs[l,ny,x]): continue
            nd=d+c+(0.05 if l==1 else 0)
            k=(l,ny,nx)
            if nd<dist.get(k,INF): dist[k]=nd; prev[k]=cur; heapq.heappush(pq,(nd+h(l,ny,nx),nd,k))
        # via
        ol=1-l
        if not obs[ol,y,x] and not obs[l,y,x]:
            # via needs clearance on both layers: check small ring free
            ok=True; vr=VIAR
            for dy in range(-vr,vr+1):
                for dx in range(-vr,vr+1):
                    if dx*dx+dy*dy>vr*vr: continue
                    yy,xx=y+dy,x+dx
                    if not(0<=yy<NY and 0<=xx<NX) or obs[0,yy,xx] or obs[1,yy,xx]: ok=False; break
                if not ok: break
            if ok:
                nd=d+25; k=(ol,y,x)
                if nd<dist.get(k,INF): dist[k]=nd; prev[k]=cur; heapq.heappush(pq,(nd+h(ol,y,x),nd,k))
    return None

def emit(path,net):
    w=POWER if net in ('+3V3','+5V','VBAT') else TRACK
    # split into runs per layer, merge collinear
    seg=[path[0]]
    for a,b in zip(path,path[1:]):
        if a[0]!=b[0]:
            flush(seg,net,w); vias.append((a[2]*G,a[1]*G,net)); seg=[b]
        else: seg.append(b)
    flush(seg,net,w)
def flush(seg,net,w):
    if len(seg)<2: return
    layer='F.Cu' if seg[0][0]==0 else 'B.Cu'
    pts=[seg[0]]; d=None
    for a,b in zip(seg,seg[1:]):
        nd=(b[1]-a[1],b[2]-a[2])
        if d is not None and nd!=d: pts.append(a)
        d=nd
    pts.append(seg[-1])
    for a,b in zip(pts,pts[1:]):
        tracks.append((a[2]*G,a[1]*G,b[2]*G,b[1]*G,w,layer,net))
    # mark halo of this net's new track cells as owned so later nets keep clearance (owner already set in route_net)

# power/ground: GND left to zones. route others, power last (wider)
import copy
order=[n for n in nets if n!='GND']
order.sort(key=lambda n:(n in ('+3V3','+5V','VBAT'), n))
owner0=owner.copy(); trackowner0=trackowner.copy(); tracks0=list(tracks); vias0=list(vias)
best=None
for attempt in range(6):
    owner[:]=owner0; trackowner[:]=trackowner0; tracks[:]=tracks0; vias[:]=vias0
    failed=[n for n in order if not route_net(n)]
    print('attempt',attempt,'failed',failed,file=sys.stderr)
    if best is None or len(failed)<len(best[0]): best=(failed,list(tracks),list(vias))
    if not failed: break
    order=failed+[n for n in order if n not in failed]
failed,tr,vi=best; tracks[:]=tr; vias[:]=vi
print('routed',len(order)-len(failed),'failed',failed,file=sys.stderr)

# ---------- GND stitching: every top-side GND pad gets a via to the bottom plane ----------
gnd=nid['GND']
halo=int(round((CLR+TRACK/2)/G))+1
obs=block.copy()
for l in range(2): obs[l]|=dilate(((owner!=-1)&(owner!=gnd))[l],halo)
vr=int(round((VIA_D/2-TRACK/2)/G))+1
stitched=0
for p in pads:
    if p['net']!='GND' or 'B.Cu' in p['layers']: continue
    cx,cy=cell(p['x'],p['y']); best=None
    for r in range(0,25):
        for dy in range(-r,r+1):
            for dx in range(-r,r+1):
                if max(abs(dx),abs(dy))!=r: continue
                x,y=cx+dx,cy+dy
                if not(vr<=x<NX-vr and vr<=y<NY-vr): continue
                ok=True
                for ey in range(-vr,vr+1):
                    for ex in range(-vr,vr+1):
                        if ex*ex+ey*ey>vr*vr: continue
                        inpad=abs((x+ex)*G-p['x'])<=p['w']/2 and abs((y+ey)*G-p['y'])<=p['h']/2
                        if obs[1,y+ey,x+ex] or (obs[0,y+ey,x+ex] and not inpad):
                            ok=False; break
                    if not ok: break
                # the short track from pad centre to via must also be clear on F.Cu
                if ok:
                    n=max(2,int(math.hypot(dx,dy))+1)
                    for i in range(n):
                        tx=cx+round(dx*i/(n-1)); ty=cy+round(dy*i/(n-1))
                        inpad=abs(tx*G-p['x'])<=p['w']/2 and abs(ty*G-p['y'])<=p['h']/2
                        if obs[0,ty,tx] and not inpad: ok=False; break
                if ok: best=(x,y); break
            if best: break
        if best: break
    if best is None: print('no via spot for GND pad',p['ref'],p['num'],file=sys.stderr); continue
    x,y=best; vx,vy=x*G,y*G
    vias.append((vx,vy,'GND'))
    if abs(vx-p['x'])>1e-6 or abs(vy-p['y'])>1e-6: tracks.append((p['x'],p['y'],vx,vy,TRACK,'F.Cu','GND'))
    rv=int(round(VIA_D/2/G))
    for ey in range(-rv,rv+1):
        for ex in range(-rv,rv+1):
            if ex*ex+ey*ey<=rv*rv: owner[:,y+ey,x+ex]=gnd
    for l in range(2): obs[l]|=dilate(((owner!=-1)&(owner!=gnd))[l],0)  # cheap: refresh not needed for others
    stitched+=1
print('GND vias',stitched,file=sys.stderr)

# ---------- tidy: dedupe co-located vias, drop dangling stubs ----------
seen=set(); vv=[]
for x,y,n in vias:
    k=(round(x,3),round(y,3))
    if k in seen: continue
    seen.add(k); vv.append((x,y,n))
vias[:]=vv
def _dseg(px,py,x1,y1,x2,y2):
    dx,dy=x2-x1,y2-y1; L2=dx*dx+dy*dy
    t=0 if L2==0 else max(0,min(1,((px-x1)*dx+(py-y1)*dy)/L2))
    return math.hypot(px-(x1+t*dx),py-(y1+t*dy))
def endpoint_touches(x,y,l,n,skip):
    for i,(a1,b1,a2,b2,w,l2,n2) in enumerate(tracks):
        if i==skip or n2!=n or l2!=l: continue
        if _dseg(x,y,a1,b1,a2,b2)<=w/2+1e-6: return True
    for vx,vy,n2 in vias:
        if n2==n and math.hypot(x-vx,y-vy)<=VIA_D/2: return True
    for p in pads:
        if p['net']==n and l in p['layers'] and abs(x-p['x'])<=p['w']/2 and abs(y-p['y'])<=p['h']/2: return True
    return False
changed=True
while changed:
    changed=False
    for i,(a1,b1,a2,b2,w,l,n) in enumerate(tracks):
        if not endpoint_touches(a1,b1,l,n,i) or not endpoint_touches(a2,b2,l,n,i):
            del tracks[i]; changed=True; break

# ---------- verify connectivity ----------
def verify():
    from collections import defaultdict
    bad=[]
    for n in nets:
        if n=='GND': continue
        segs=[t for t in tracks if t[6]==n]; vs=[v for v in vias if v[2]==n]
        mypads=[p for p in pads if p['net']==n]
        # nodes: segment endpoints (layer,x,y); vias join layers; pads join everything inside their box
        par={}
        def f(a):
            par.setdefault(a,a)
            while par[a]!=a: par[a]=par[par[a]]; a=par[a]
            return a
        def u(a,b): par[f(a)]=f(b)
        k=lambda l,x,y:(l,round(x,3),round(y,3))
        def dist(px,py,x1,y1,x2,y2):
            dx,dy=x2-x1,y2-y1; L2=dx*dx+dy*dy
            t=0 if L2==0 else max(0,min(1,((px-x1)*dx+(py-y1)*dy)/L2))
            return math.hypot(px-(x1+t*dx),py-(y1+t*dy))
        for x1,y1,x2,y2,w,l,_ in segs: u(k(l,x1,y1),k(l,x2,y2))
        for x1,y1,x2,y2,w,l,_ in segs:
            for (x,y) in ((x1,y1),(x2,y2)):
                for a1,b1,a2,b2,w2,l2,_ in segs:
                    if l2==l and dist(x,y,a1,b1,a2,b2)<=w2/2+1e-3: u(k(l,x,y),k(l,a1,b1))
        for x,y,_ in vs:
            u(k('F.Cu',x,y),k('B.Cu',x,y))
            for a1,b1,a2,b2,w2,l2,_ in segs:
                if dist(x,y,a1,b1,a2,b2)<=w2/2+VIA_D/2-1e-3: u(k(l2,x,y),k(l2,a1,b1))
        for i,p in enumerate(mypads):
            pk=('pad',i)
            for x1,y1,x2,y2,w,l,_ in segs:
                for (x,y) in ((x1,y1),(x2,y2)):
                    if l in p['layers'] and abs(x-p['x'])<=p['w']/2+1e-3 and abs(y-p['y'])<=p['h']/2+1e-3: u(pk,k(l,x,y))
            for x,y,_ in vs:
                if abs(x-p['x'])<=p['w']/2+1e-3 and abs(y-p['y'])<=p['h']/2+1e-3: u(pk,k('F.Cu',x,y))
        roots={f(('pad',i)) for i in range(len(mypads))}
        if len(roots)>1: bad.append((n,len(roots)))
    print('connectivity problems:',bad,file=sys.stderr)
verify()

# ---------- write ----------
netid={}
for e in pcb:
    if isinstance(e,list) and e[0]==Sym('net'): netid[e[2]]=e[1]
add=[]
for x1,y1,x2,y2,w,layer,net in tracks:
    add.append(f'(segment (start {x1:.3f} {y1:.3f}) (end {x2:.3f} {y2:.3f}) (width {w}) (layer "{layer}") (net {netid[net]}) (uuid "{U()}"))')
for x,y,net in vias:
    add.append(f'(via (at {x:.3f} {y:.3f}) (size {VIA_D}) (drill {VIA_DR}) (layers "F.Cu" "B.Cu") (net {netid[net]}) (uuid "{U()}"))')
out=txt.rstrip()
assert out.endswith(')')
out=out[:-1]+'\n'+'\n'.join(add)+'\n)\n'
open(DST,'w').write(out)
print('tracks',len(tracks),'vias',len(vias),file=sys.stderr)
