import sexpdata as S, uuid, math, sys
from collections import defaultdict
SCH = '/mnt/user-data/outputs/kizami.kicad_sch'
U = lambda: str(uuid.uuid4())
Sym = S.Symbol

# ---------- read schematic: symbols (ref, uuid, footprint, value) + nets ----------
sch = S.loads(open(SCH).read())
ROOT = [e for e in sch if isinstance(e,list) and e[0]==Sym('uuid')][0][1]
libs = {}
pinname = {}
symlib = {}
for e in sch:
    if isinstance(e,list) and e[0]==Sym('lib_symbols'):
        for s in e[1:]: libs[s[1]] = s
def pins_of(sym):
    out=[]
    def walk(x):
        if isinstance(x,list) and x and x[0]==Sym('pin'):
            g=lambda k:[e for e in x if isinstance(e,list) and e[0]==Sym(k)][0]
            out.append((g('number')[1], g('at')[1], g('at')[2]))
            pinname[(sym[1],g('number')[1])]=g('name')[1]
        elif isinstance(x,list):
            for e in x: walk(e)
    walk(sym); return out
key=lambda x,y:(round(x,2),round(y,2))
parent={}
def find(a):
    parent.setdefault(a,a)
    while parent[a]!=a: parent[a]=parent[parent[a]]; a=parent[a]
    return a
def union(a,b): parent[find(a)]=find(b)
segs=[]; pts=defaultdict(list); symbols={}
for e in sch:
    if not isinstance(e,list): continue
    t=e[0].value() if isinstance(e[0],Sym) else ''
    g=lambda k:[k2 for k2 in e if isinstance(k2,list) and k2[0]==Sym(k)]
    if t=='wire':
        a,b=g('pts')[0][1],g('pts')[0][2]; segs.append((key(a[1],a[2]),key(b[1],b[2])))
    elif t=='label':
        at=g('at')[0]; pts[key(at[1],at[2])].append(('LBL',e[1]))
    elif t=='symbol':
        lid=g('lib_id')[0][1]; at=g('at')[0]
        prop={p[1]:p[2] for p in g('property')}
        ref=prop['Reference']; suuid=g('uuid')[0][1]
        if not lid.startswith('power:'):
            symlib[ref]=lid
            symbols[ref]=dict(uuid=suuid, fp=prop.get('Footprint',''), value=prop.get('Value',''), lcsc=prop.get('LCSC',''))
        for num,px,py in pins_of(libs[lid]):
            k=key(at[1]+px, at[2]-py)
            if lid.startswith('power:'):
                if 'PWR_FLAG' not in lid: pts[k].append(('PWR',lid.split(':')[1]))
            else: pts[k].append(('PIN',ref,num))
def on_seg(p,s):
    (x1,y1),(x2,y2)=s; x,y=p
    return min(x1,x2)-1e-3<=x<=max(x1,x2)+1e-3 and min(y1,y2)-1e-3<=y<=max(y1,y2)+1e-3 and abs((x2-x1)*(y-y1)-(y2-y1)*(x-x1))<1e-3
allpts=set(pts)|{p for s in segs for p in s}
for s in segs:
    for p in allpts:
        if on_seg(p,s): union(p,s[0])
byname=defaultdict(list)
for k,v in pts.items():
    for x in v:
        if x[0] in ('LBL','PWR'): byname[x[1]].append(k)
for n,ks in byname.items():
    for k in ks[1:]: union(ks[0],k)
netname={}; netpins=defaultdict(list)
for k,v in pts.items():
    r=find(k)
    for x in v:
        if x[0]=='LBL': netname[r]='/'+x[1]
        elif x[0]=='PWR': netname[r]=x[1]
        else: netpins[r].append((x[1],x[2]))
nets=[]  # (name, [(ref,pad)])
for r,p in netpins.items():
    if r in netname: nets.append((netname[r],p))
    elif len(p)>1: nets.append((f"Net-({p[0][0]}-Pad{p[0][1]})",p))
nets.sort()
padnet={}
for n,pl in nets:
    for ref,pad in pl: padnet[(ref,pad)]=n
# every unconnected pin gets KiCad's own 'unconnected-(REF-NAME-PadN)' net name
for ref,lid in symlib.items():
    for (l,num),name in pinname.items():
        if l!=lid or (ref,num) in padnet or not num: continue
        n=f"unconnected-({ref}-{name.replace('/','{slash}')}-Pad{num})"
        nets.append((n,[(ref,num)])); padnet[(ref,num)]=n
nets.sort()
netid={n:i+1 for i,(n,_) in enumerate(nets)}
print('nets',len(nets),'symbols',len(symbols), file=sys.stderr)

# ---------- placement (board mm, origin top-left, y down) ----------
W,H = 80,45
PLACE = {  # ref: (x, y, rot)
 'H1':(4,4,0),'H2':(76,4,0),'H3':(4,41,0),'H4':(76,41,0),
 'U1':(44,13,0),       # ESP32, antenna hangs over top edge
 'J1':(11,5,90),        # OLED header, pads run along +x; module hangs down over top-left
 'R3':(30,9,0),'C1':(30,12,0),'C2':(30,15,0),'C3':(30,18,0),
 'U2':(66,11,0),       # DS3231
 'R1':(60,19,0),'R2':(64,19,0),'C9':(68,19,0),
 'J2':(76,11,0),'J3':(76,18,0),   # button headers, pads run along +y
 'R8':(72,24,0),'R9':(76,24,0),
 'R4':(57,21.5,0),
 'BT1':(60,33,0),      # CR2032 holder
 'U3':(25,29,180),       # CH340C
 'C6':(36,25.5,0),
 'R7':(41,27,0),'R11':(45,27,0),'Q1':(41,32,0),'Q2':(46,32,0),
 'J6':(34,40.5,0),     # USB-C on front (bottom) edge
 'R5':(24.5,38.5,0),'R6':(24.5,41.5,0),
 'U4':(13,36,0),'C4':(7,31.5,0),'C5':(20,36,0),
 'J4':(10,43,90),      # jack header, pads run along +x
 'R10':(18.5,43.3,0),'C7':(22,43.3,0),'C8':(25.5,43.3,0),
}
HOLES=[(4,4),(76,4),(4,41),(76,41)]
FPFILE={  # footprint lib name -> local file
 'RF_Module:ESP32-WROOM-32':'ESP32-WROOM-32','Package_SO:SOIC-16W_7.5x10.3mm_P1.27mm':'SOIC-16W_7.5x10.3mm_P1.27mm',
 'Package_SO:SOIC-16_3.9x9.9mm_P1.27mm':'SOIC-16_3.9x9.9mm_P1.27mm','Connector_USB:USB_C_Receptacle_HRO_TYPE-C-31-M-12':'USB_C_Receptacle_HRO_TYPE-C-31-M-12',
 'Package_TO_SOT_SMD:SOT-223-3_TabPin2':'SOT-223-3_TabPin2','Package_TO_SOT_SMD:SOT-23':'SOT-23',
 'Resistor_SMD:R_0603_1608Metric':'R_0603_1608Metric','Capacitor_SMD:C_0603_1608Metric':'C_0603_1608Metric',
 'Battery:BatteryHolder_Keystone_3034_1x20mm':'BatteryHolder_Keystone_3034_1x20mm',
 'Connector_PinHeader_2.54mm:PinHeader_1x04_P2.54mm_Vertical':'PinHeader_1x04_P2.54mm_Vertical',
 'Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical':'PinHeader_1x02_P2.54mm_Vertical',
 'Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical':'PinHeader_1x03_P2.54mm_Vertical',
 'MountingHole:MountingHole_3.2mm_M3':'MountingHole_3.2mm_M3',
}
def load_fp(name):
    return S.loads(open(f'fp/{FPFILE[name]}.kicad_mod').read())

def footprint(name, ref, value, x, y, rot, path=None, lcsc=''):
    fp = load_fp(name)
    out=[Sym('footprint'), name]
    for e in fp[2:]:
        if isinstance(e,list) and e[0] in (Sym('version'),Sym('generator'),Sym('generator_version')): continue
        if isinstance(e,list) and e[0]==Sym('pad') and e[2]==Sym('thru_hole') and any(isinstance(k,list) and k[0]==Sym('drill') and isinstance(k[1],(int,float)) and k[1]<0.3 for k in e): continue  # drop 0.2 mm thermal vias (JLCPCB min 0.3)
        out.append(e)
    # insert at/uuid/path after layer
    idx=[i for i,e in enumerate(out) if isinstance(e,list) and e[0]==Sym('layer')][0]+1
    ins=[[Sym('uuid'),U()],[Sym('at'),x,y,rot]]
    if path: ins.append([Sym('path'),path])
    out[idx:idx]=ins
    for e in out:
        if isinstance(e,list) and e[0]==Sym('property'):
            if e[1]=='Reference':
                e[2]=ref
                if ref.startswith('H') and not any(isinstance(k,list) and k[0]==Sym('hide') for k in e): e.append([Sym('hide'),Sym('yes')])
            elif e[1]=='Value': e[2]=value
            elif e[1]=='Footprint': e[2]=name
            elif e[1]=='Datasheet': e[2]=''
            elif e[1]=='Description': e[2]=''
            # property text inherits fp rotation
        if isinstance(e,list) and e[0]==Sym('pad'):
            at=[k for k in e if isinstance(k,list) and k[0]==Sym('at')][0]
            if len(at)>3: at[3]=(at[3]+rot)%360
            elif rot: at.append(rot%360)
            n=padnet.get((ref,e[1]))
            if n and e[1]!='':
                # remove existing net, add ours
                e[:] = [k for k in e if not (isinstance(k,list) and k[0]==Sym('net'))]
                e.append([Sym('net'),netid[n],n])
            if not any(isinstance(k,list) and k[0]==Sym('uuid') for k in e): e.append([Sym('uuid'),U()])
    if lcsc: out.append([Sym('property'),'LCSC',lcsc,[Sym('at'),0,0,0],[Sym('layer'),'F.Fab'],[Sym('hide'),Sym('yes')],[Sym('uuid'),U()],[Sym('effects'),[Sym('font'),[Sym('size'),1,1],[Sym('thickness'),0.15]]]])
    return out

items=[]
for ref,(x,y,rot) in PLACE.items():
    s=symbols[ref]
    items.append(footprint(s['fp'], ref, s['value'], x, y, rot, path=f"/{ROOT}/{s['uuid']}", lcsc=s['lcsc']))
missing=set(symbols)-set(PLACE)
print('unplaced:',missing, file=sys.stderr)

# board outline
def gr_line(x1,y1,x2,y2,layer='Edge.Cuts',w=0.1):
    return f'(gr_line (start {x1} {y1}) (end {x2} {y2}) (stroke (width {w}) (type default)) (layer "{layer}") (uuid "{U()}"))'
edge=[gr_line(0,0,W,0),gr_line(W,0,W,H),gr_line(W,H,0,H),gr_line(0,H,0,0)]
def gr_text(t,x,y,layer='F.SilkS',size=1.2,rot=0):
    return f'(gr_text "{t}" (at {x} {y} {rot}) (layer "{layer}") (uuid "{U()}") (effects (font (size {size} {size}) (thickness 0.15)) (justify left)))'
texts=[gr_text('KIZAMI CORE rev A',56,44,size=1.0), gr_text('haskylabs.com',56,44,'B.SilkS',1.0),
       gr_text('OLED module sits here (over J1)',2,20,'F.Fab',1.0)]
gnd=netid['GND']
def zone(layer):
    return (f'(zone (net {gnd}) (net_name "GND") (layer "{layer}") (uuid "{U()}") (hatch edge 0.5) (connect_pads yes (clearance 0.3)) '
            f'(min_thickness 0.25) (filled_areas_thickness no) (fill yes (thermal_gap 0.5) (thermal_bridge_width 0.5)) '
            f'(polygon (pts (xy 0 0) (xy {W} 0) (xy {W} {H}) (xy 0 {H}))))')

nettxt='\n'.join(f' (net {i} "{n}")' for n,i in netid.items())
fptxt='\n'.join(S.dumps(it,true_as='yes',false_as='no') for it in items)
pcb=f'''(kicad_pcb (version 20241229) (generator "pcbnew") (generator_version "9.0")
 (general (thickness 1.6) (legacy_teardrops no))
 (paper "A4")
 (layers
  (0 "F.Cu" signal) (2 "B.Cu" signal)
  (9 "F.Adhes" user "F.Adhesive") (11 "B.Adhes" user "B.Adhesive")
  (13 "F.Paste" user) (15 "B.Paste" user)
  (5 "F.SilkS" user "F.Silkscreen") (7 "B.SilkS" user "B.Silkscreen")
  (1 "F.Mask" user) (3 "B.Mask" user)
  (17 "Dwgs.User" user "User.Drawings") (19 "Cmts.User" user "User.Comments")
  (21 "Eco1.User" user "User.Eco1") (23 "Eco2.User" user "User.Eco2")
  (25 "Edge.Cuts" user) (27 "Margin" user)
  (31 "F.CrtYd" user "F.Courtyard") (29 "B.CrtYd" user "B.Courtyard")
  (35 "F.Fab" user) (33 "B.Fab" user)
 )
 (setup (pad_to_mask_clearance 0) (allow_soldermask_bridges_in_footprints no))
 (net 0 "")
{nettxt}
{fptxt}
{chr(10).join(edge)}
{chr(10).join(texts)}
{zone("F.Cu")}
{zone("B.Cu")}
)
'''
open('/mnt/user-data/outputs/kizami.kicad_pcb','w').write(pcb)
S.loads(pcb)
print('ok',len(pcb), file=sys.stderr)
